from flask import Flask, request, render_template
app = Flask(__name__)

@app.route("/feedback", methods = ["POST", "GET"])
def feedback():
    if request.method == "POST":
        name = request.form.get("username")
        message = request.form.get("message")
        return render_template("thanku.html", user = name, message=message)
    return render_template("feedback.html")
    
if __name__ == "__main__":
    app.run(debug=True)