from flask import Flask, request, Response, redirect, url_for, session, render_template
app = Flask(__name__)
app.secret_key = "SuperSecret"

#HomePage
@app.route("/")
def login():
    return render_template("login.html")
@app.route("/submit", methods =["POST"])
def submit():
    username= request.form.get("username")
    password= request.form.get("password")

    if username== "admin" and password == "123":
        session["user"] = username
        return render_template("welcome.html", name = username)
    else:
        return "invalid Creds"

if __name__ == "__main__":
    app.run(debug=True)
